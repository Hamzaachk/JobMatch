import React from "react";

function About() {
  return (
    <div>
      <h1>About Page</h1>
      <p>
        This page provides information about the purpose of this application.
      </p>
    </div>
  );
}

export default About;
