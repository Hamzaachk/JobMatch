import React from "react";

function Profile() {
  // Mock data; replace with API call
  const previousUploads = ["Resume1.pdf", "Resume2.docx"];
  const jobApplications = [
    { position: "Software Engineer", result: "80%" },
    { position: "Data Scientist", result: "90%" },
  ];

  return (
    <div className="profile">
      <h2>Profile</h2>
      <div>
        <h3>Personal Details</h3>
        <input placeholder="Name" />
        <input placeholder="Email" />
        <input type="date" placeholder="Date of Birth" />
      </div>
      <div>
        <h3>Previous Uploads</h3>
        <ul>
          {previousUploads.map((file, index) => (
            <li key={index}>{file}</li>
          ))}
        </ul>
      </div>
      <div>
        <h3>Job Applications</h3>
        <ul>
          {jobApplications.map((app, index) => (
            <li key={index}>
              {app.position}: {app.result}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Profile;
