import React from "react";
import "./ResumeAnalysis.css";

function ResumeAnalysis() {
  // Mock data for demonstration purposes; replace with dynamic data from an API or service
  const resumeScore = 75; // Score out of 100
  const suggestions = [
    "Add measurable achievements (e.g., increased sales by 20%).",
    "Include recent certifications or training.",
    "Improve formatting for better readability.",
  ];
  const recommendedJobs = [
    { title: "Data Scientist", type: "Full-Time", id: 1 },
    { title: "Cybersecurity Analyst", type: "Part-Time", id: 2 },
    { title: "Mobile App Developer", type: "Full-Time", id: 3 },
  ];

  const handleApply = (jobId) => {
    // Implement the functionality for applying to a job
    console.log(`Applied for job with ID: ${jobId}`);
    alert("Application submitted successfully!");
  };

  return (
    <div className="resume-analysis">
      <h2>Resume Analysis Results</h2>
      <div className="score-section">
        <p>Your Resume Score:</p>
        <div className="score">{resumeScore}%</div>
      </div>

      <div className="suggestions-section">
        <h3>Suggestions for Improvement</h3>
        <ul>
          {suggestions.map((suggestion, index) => (
            <li key={index}>{suggestion}</li>
          ))}
        </ul>
      </div>

      <div className="recommended-jobs-section">
        <h3>Recommended Job Positions</h3>
        <ul>
          {recommendedJobs.map((job) => (
            <li key={job.id}>
              <div>
                <strong>{job.title}</strong> ({job.type})
              </div>
              <button onClick={() => handleApply(job.id)}>
                Apply for this Position
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default ResumeAnalysis;
