import React, { useState } from "react";

function UploadResume() {
  const [message, setMessage] = useState("");

  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (!file.name.endsWith(".pdf") && !file.name.endsWith(".docx")) {
      setMessage("Invalid file type. Please upload a PDF or DOCX file.");
    } else {
      setMessage("File uploaded successfully!");
    }
  };

  return (
    <div className="upload-resume">
      <h2>Upload Resume</h2>
      <input type="file" onChange={handleUpload} />
      {message && <p>{message}</p>}
    </div>
  );
}

export default UploadResume;
