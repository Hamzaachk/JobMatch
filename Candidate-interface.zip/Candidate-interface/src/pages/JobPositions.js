import React from "react"; 

function JobPositions() {
  const jobPositions = [
    {
      title: "Software Engineer",
      type: "Full-Time",
      requirements: "Experience in React, Node.js.",
    },
    // Add other positions
  ];

  return (
    <div className="job-positions">
      <h2>Available Jobs</h2>
      {jobPositions.map((job, index) => (
        <div key={index} className="job">
          <h3>{job.title}</h3>
          <p>Type: {job.type}</p>
          <p>Requirements: {job.requirements}</p>
        </div>
      ))}
    </div>
  );
}

export default JobPositions;
