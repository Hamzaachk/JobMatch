import React from "react";

function Home() {
  return (
    <div>
      <h1>Welcome to the Candidate Interface</h1>
      <p>This is the home page for job applications and matches.</p>
    </div>
  );
}

export default Home;
