import React, { useState } from "react";
import "./Login.css";

function Login() {
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);
  const [message, setMessage] = useState("");

  const handleCreateAccount = () => {
    // Add validation and API integration here
    setMessage("Your account has been created successfully");
  };

  const handleLogin = () => {
    // Add validation and API call for login
    setMessage("Invalid username or password");
  };

  return (
    <div className="login-container">
      {isCreatingAccount ? (
        <div className="create-account">
          <h2>Create Account</h2>
          <input placeholder="First Name" />
          <input placeholder="Last Name" />
          <input type="date" placeholder="Date of Birth" />
          <input placeholder="Email" />
          <input placeholder="Confirm Email" />
          <input type="password" placeholder="Password" />
          <button onClick={handleCreateAccount}>Create Account</button>
          {message && <p>{message}</p>}
        </div>
      ) : (
        <div className="login">
          <h2>Login</h2>
          <input placeholder="Email" />
          <input type="password" placeholder="Password" />
          <button onClick={handleLogin}>Login</button>
          <button onClick={() => setIsCreatingAccount(true)}>
            Create Account
          </button>
          {message && <p>{message}</p>}
        </div>
      )}
    </div>
  );
}

export default Login;
